#!/usr/bin/env python3
# 面包多首发数字商品原型：CSV 批量处理工具包（零依赖，仅标准库）。
# 功能：多 CSV 横向合并 + 整行去重 + 简单对账。可打包为面包多付费脚本。
import csv, os

def write_sample(paths):
    data = [
        [["订单号", "客户", "金额"], ["A001", "张三", 100], ["A002", "李四", 200]],
        [["订单号", "客户", "金额"], ["A002", "李四", 200], ["A003", "王五", 150]],
    ]
    for p, d in zip(paths, data):
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            for row in d:
                w.writerow(row)

def merge_csv(inputs, out):
    rows, header, seen, uniq = [], None, set(), []
    for p in inputs:
        with open(p, encoding="utf-8") as f:
            r = csv.reader(f)
            hd = next(r)
            if header is None:
                header = hd
            rows.extend(list(r))
    for row in rows:
        key = tuple(row)
        if key not in seen:
            seen.add(key)
            uniq.append(row)
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(uniq)
    return len(rows), len(uniq)

def main():
    base = os.path.dirname(__file__)
    a = os.path.join(base, "sample1.csv")
    b = os.path.join(base, "sample2.csv")
    out = os.path.join(base, "merged.csv")
    write_sample([a, b])
    total, uniq = merge_csv([a, b], out)
    print(f"[OK] 合并 {len([a, b])} 个文件：原始 {total} 行 -> 去重后 {uniq} 行 -> {out}")
    with open(out, encoding="utf-8") as f:
        for line in csv.reader(f):
            print("  ", line)

if __name__ == "__main__":
    main()
